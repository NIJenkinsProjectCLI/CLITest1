# CLITest1
This is for learning how to use GitHub with LabVIEW 2018 CLI and Jenkins
